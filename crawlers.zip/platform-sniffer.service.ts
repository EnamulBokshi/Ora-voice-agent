// src/ingestion/platform-sniffer.service.ts
import { Injectable, Logger } from '@nestjs/common';
import { PlatformDetectionResult, PlatformType } from './types/ingestion.types';

const FETCH_TIMEOUT_MS = 6000;
const USER_AGENT = 'ORA-Sync/1.0 (+https://ora.ai/bot; Storefront Intelligence)';

/**
 * Detects which e-commerce platform a merchant domain runs on.
 * This determines whether the crawler can use a fast, structured
 * "no-scraping" path (Shopify/Woo public APIs) or must fall back
 * to generic sitemap + HTML crawling.
 *
 * IMPORTANT: only ever probes the merchant's own domain, and only
 * hits endpoints those platforms intentionally expose as public,
 * unauthenticated APIs (no auth bypass, no scraping of gated data).
 */
@Injectable()
export class PlatformSnifferService {
  private readonly logger = new Logger(PlatformSnifferService.name);

  async detect(domain: string): Promise<PlatformDetectionResult> {
    const normalizedDomain = this.normalizeDomain(domain);

    const shopify = await this.probeShopify(normalizedDomain);
    if (shopify) return shopify;

    const woo = await this.probeWooCommerce(normalizedDomain);
    if (woo) return woo;

    return {
      platform: 'custom',
      domain: normalizedDomain,
      confidence: 'low',
      evidence: ['No Shopify or WooCommerce signature found; falling back to generic crawl'],
    };
  }

  private normalizeDomain(domain: string): string {
    return domain
      .trim()
      .replace(/^https?:\/\//i, '')
      .replace(/\/+$/, '');
  }

  private async probeShopify(domain: string): Promise<PlatformDetectionResult | null> {
    try {
      const res = await this.fetchWithTimeout(`https://${domain}/products.json?limit=1`);
      if (!res.ok) return null;

      const evidence: string[] = [];
      const shopIdHeader = res.headers.get('x-shopid') || res.headers.get('x-shardid');
      if (shopIdHeader) evidence.push(`Shopify header present: ${shopIdHeader}`);

      const body = await res.json().catch(() => null);
      const hasProductsArray = body && Array.isArray(body.products);
      if (hasProductsArray) evidence.push('/products.json returned a valid products[] payload');

      if (shopIdHeader || hasProductsArray) {
        return {
          platform: 'shopify',
          domain,
          confidence: shopIdHeader && hasProductsArray ? 'high' : 'low',
          evidence,
        };
      }
      return null;
    } catch (err) {
      this.logger.debug(`Shopify probe failed for ${domain}: ${(err as Error).message}`);
      return null;
    }
  }

  private async probeWooCommerce(domain: string): Promise<PlatformDetectionResult | null> {
    try {
      const res = await this.fetchWithTimeout(
        `https://${domain}/wp-json/wc/store/v1/products?per_page=1`,
      );
      if (!res.ok) return null;

      const body = await res.json().catch(() => null);
      if (Array.isArray(body)) {
        return {
          platform: 'woocommerce',
          domain,
          confidence: 'high',
          evidence: ['/wp-json/wc/store/v1/products returned a valid array payload'],
        };
      }
      return null;
    } catch (err) {
      this.logger.debug(`WooCommerce probe failed for ${domain}: ${(err as Error).message}`);
      return null;
    }
  }

  private async fetchWithTimeout(url: string): Promise<Response> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
    try {
      return await fetch(url, {
        signal: controller.signal,
        headers: { 'User-Agent': USER_AGENT, Accept: 'application/json' },
      });
    } finally {
      clearTimeout(timeout);
    }
  }
}
