// src/ingestion/sitemap-crawler.service.ts
import { Injectable, Logger } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { PlatformSnifferService } from './platform-sniffer.service';
import { PlatformFastPathService } from './platform-fast-path.service';
import { SitemapDiscoveryService } from './sitemap-discovery.service';
import { CrawlJobData, CrawlUrlJobData, DiscoveredUrl } from './types/ingestion.types';

const HTML_CRAWL_QUEUE = 'ora-html-crawl';
const CRAWLER_CONCURRENCY_PER_TENANT = 5; // politeness cap, see processor's limiter

/**
 * Entry point for "Sync from Website URL". Called from the onboarding flow
 * with just a tenantId + domain. Decides whether the merchant qualifies for
 * the Shopify/WooCommerce fast path (no scraping, direct JSON) or needs the
 * generic sitemap + HTML crawl fallback, then fans out work accordingly.
 */
@Injectable()
export class SitemapCrawlerService {
  private readonly logger = new Logger(SitemapCrawlerService.name);

  constructor(
    private readonly sniffer: PlatformSnifferService,
    private readonly fastPath: PlatformFastPathService,
    private readonly discovery: SitemapDiscoveryService,
    @InjectQueue(HTML_CRAWL_QUEUE) private readonly htmlCrawlQueue: Queue<CrawlUrlJobData>,
    // Inject your real services here — left as constructor params so this
    // drops into your existing IngestionModule without restructuring:
    // private readonly productService: ProductService,
    // private readonly knowledgeService: KnowledgeService,
  ) {}

  async syncFromWebsite({ tenantId, domain }: CrawlJobData): Promise<{
    platform: string;
    productsIngested: number;
    knowledgeDocsIngested: number;
    htmlCrawlJobsQueued: number;
  }> {
    const detection = await this.sniffer.detect(domain);
    this.logger.log(
      `Platform detection for ${domain} (tenant=${tenantId}): ${detection.platform} (${detection.confidence})`,
    );

    if (detection.platform === 'shopify') {
      return this.runShopifyFastPath(tenantId, detection.domain);
    }

    if (detection.platform === 'woocommerce') {
      return this.runWooCommerceFastPath(tenantId, detection.domain);
    }

    return this.runGenericCrawl(tenantId, detection.domain);
  }

  // ---- Fast paths: no HTML scraping, direct platform JSON ----

  private async runShopifyFastPath(tenantId: string, domain: string) {
    const [products, policies] = await Promise.all([
      this.fastPath.fetchShopifyProducts(domain),
      this.fastPath.fetchShopifyPolicies(domain),
    ]);

    // await this.productService.upsertMany(tenantId, products);
    // await this.knowledgeService.upsertMany(tenantId, policies);
    this.logger.log(
      `[fast-path:shopify] tenant=${tenantId} products=${products.length} policies=${policies.length}`,
    );

    // Shopify also benefits from a light FAQ sweep via sitemap, since
    // /policies.json only covers the four standard policy types.
    const discovered = await this.discovery.discover(domain);
    const faqUrls = discovered.filter((d) => d.kind === 'faq');
    const queued = await this.enqueueHtmlCrawl(tenantId, domain, 'shopify', faqUrls);

    return {
      platform: 'shopify',
      productsIngested: products.length,
      knowledgeDocsIngested: policies.length,
      htmlCrawlJobsQueued: queued,
    };
  }

  private async runWooCommerceFastPath(tenantId: string, domain: string) {
    const [products, pages] = await Promise.all([
      this.fastPath.fetchWooCommerceProducts(domain),
      this.fastPath.fetchWooCommercePages(domain),
    ]);

    // await this.productService.upsertMany(tenantId, products);
    // Raw WP page HTML still needs Readability/Turndown cleanup — route
    // through the same HTML crawl worker rather than storing raw HTML.
    const pageUrls: DiscoveredUrl[] = pages.map((p) => ({
      url: p.sourceUrl,
      kind: p.category === 'general' ? 'page' : p.category,
      sourceHint: 'platform-index',
    }));
    const queued = await this.enqueueHtmlCrawl(tenantId, domain, 'woocommerce', pageUrls);

    this.logger.log(
      `[fast-path:woocommerce] tenant=${tenantId} products=${products.length} pagesQueued=${queued}`,
    );

    return {
      platform: 'woocommerce',
      productsIngested: products.length,
      knowledgeDocsIngested: 0, // counted once the queued jobs complete
      htmlCrawlJobsQueued: queued,
    };
  }

  // ---- Generic fallback: sitemap discovery + HTML crawl for everything ----

  private async runGenericCrawl(tenantId: string, domain: string) {
    const discovered = await this.discovery.discover(domain);

    if (discovered.length === 0) {
      this.logger.warn(`No sitemap for ${domain}; nothing to crawl (manual review may be needed)`);
      return {
        platform: 'custom',
        productsIngested: 0,
        knowledgeDocsIngested: 0,
        htmlCrawlJobsQueued: 0,
      };
    }

    const queued = await this.enqueueHtmlCrawl(tenantId, domain, 'custom', discovered);

    this.logger.log(`[generic-crawl] tenant=${tenantId} domain=${domain} urlsQueued=${queued}`);

    return {
      platform: 'custom',
      productsIngested: 0, // counted once the queued jobs complete
      knowledgeDocsIngested: 0,
      htmlCrawlJobsQueued: queued,
    };
  }

  private async enqueueHtmlCrawl(
    tenantId: string,
    domain: string,
    platform: CrawlUrlJobData['platform'],
    urls: DiscoveredUrl[],
  ): Promise<number> {
    if (urls.length === 0) return 0;

    await this.htmlCrawlQueue.addBulk(
      urls.map((discovered) => ({
        name: 'crawl-url',
        data: { tenantId, domain, platform, discovered } satisfies CrawlUrlJobData,
        opts: {
          // Politeness: cap per-tenant concurrency so we never hammer a
          // single merchant's origin, even on a big catalog.
          removeOnComplete: 1000,
          removeOnFail: 500,
        },
      })),
    );

    return urls.length;
  }
}

export { HTML_CRAWL_QUEUE, CRAWLER_CONCURRENCY_PER_TENANT };
