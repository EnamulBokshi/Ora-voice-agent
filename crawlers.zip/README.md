# ORA Ingestion Pipeline — Implementation Notes

## What's here

| File | Purpose |
|---|---|
| `types/ingestion.types.ts` | Shared interfaces used across every file below |
| `platform-sniffer.service.ts` | Detects Shopify / WooCommerce / custom from the domain |
| `platform-fast-path.service.ts` | Direct calls to `/products.json`, `/policies.json`, WC Store API — **no HTML parsing** |
| `sitemap-discovery.service.ts` | Walks `sitemap.xml` / `sitemap_index.xml`, classifies URLs as product/policy/faq/page |
| `extractors/json-ld.extractor.ts` | Pulls `Product` schema from `<script type="application/ld+json">`, falls back to OpenGraph |
| `extractors/readability.extractor.ts` | Mozilla Readability → Turndown, for policy/FAQ/general page bodies |
| `sitemap-crawler.service.ts` | Orchestrator — picks fast path vs generic crawl, fans out BullMQ jobs |
| `sitemap-crawler.processor.ts` | BullMQ worker — fetches one URL, routes to the right extractor |
| `ingestion.module.ts` | Wires it all into a NestJS module |

## Routing logic (URL → destination)

```
discover URL
   │
   ├─ platform === shopify   ──► /products.json + /policies.json directly (no crawl)
   │                              + sitemap sweep for FAQ URLs only
   │
   ├─ platform === woocommerce ─► WC Store API for products
   │                              + WP Pages API, routed through Readability for cleanup
   │
   └─ platform === custom     ──► full sitemap discovery → per-URL HTML crawl
          │
          ├─ kind === product        → JsonLdExtractor → Product collection
          ├─ kind === policy|faq|page → ReadabilityExtractor → KnowledgeBase collection
          └─ kind === unknown         → skipped
```

## Wiring into your existing services

I left `ProductService` / `KnowledgeService` calls commented out in
`sitemap-crawler.service.ts` and `sitemap-crawler.processor.ts` (marked with `// await this.productService...`)
since I don't have your actual Mongoose schema shapes. Steps to connect:

1. Import `ProductModule` / `KnowledgeModule` into `IngestionModule`.
2. Inject `ProductService` and `KnowledgeService` into `SitemapCrawlerService` and `SitemapCrawlerProcessor`.
3. Uncomment the `upsertMany` / `upsertOne` / `createKnowledgeBase` calls — the extracted
   objects (`ExtractedProduct`, `ExtractedKnowledgeDoc`) already match the field names your
   architecture doc listed (title, price, currency, images, availability, variants / category, markdown).
4. `KnowledgeService.createKnowledgeBase()` should still own chunking (~500 chars) and embedding —
   this pipeline only hands it clean Markdown, it doesn't chunk/embed itself.

## Dependencies to install

```bash
npm install cheerio jsdom @mozilla/readability turndown fast-xml-parser
npm install -D @types/turndown
```

(`@nestjs/bullmq` and `bullmq` assumed already present given your existing BullMQ usage.)

## Safeguards already built in

- **Per-domain URL cap** (`MAX_URLS_PER_DOMAIN = 5000`) and **sitemap recursion depth cap** (`MAX_SITEMAP_DEPTH = 2`) — prevents a malformed or huge sitemap from blowing up a job.
- **Global crawl rate limit**: `limiter: { max: 5, duration: 1000 }` on the BullMQ worker — max 5 HTML fetches/sec across all tenants combined, so no single onboarding burst hammers a merchant's origin.
- **Fetch timeouts** (6–10s) on every outbound call, so a slow/hanging origin can't stall the queue.
- **Content-Type check** before parsing — refuses to run Readability/Cheerio on non-HTML responses.
- **Minimum content length** threshold in Readability extraction — filters out pages where only nav/footer got captured.
- **`User-Agent` clearly identifies the bot** (`ORA-Sync/1.0`) with a URL, rather than spoofing a browser UA — this is a legitimate first-party sync tool operating on the merchant's own site, not a scraper evading detection.

## Known gaps / next steps

- **robots.txt honoring**: not yet implemented. Add a check before `enqueueHtmlCrawl` (e.g. via the `robots-parser` npm package) so draft/noindex pages a merchant has explicitly excluded aren't pulled in.
- **Per-tenant concurrency isolation**: the current limiter is global (5 req/s across *all* tenants). For a large merchant batch-syncing at once, consider a BullMQ `group` key per `tenantId` so one huge catalog doesn't starve other tenants' onboarding.
- **Shopify currency**: `/products.json` doesn't include `priceCurrency` — resolve it once per shop via `/meta.json` or the widget's live DOM read, then apply to all products.
- **Retry/backoff on 429s**: currently only retries via BullMQ's generic `attempts: 3` — worth adding `Retry-After` header handling for platforms that rate-limit aggressively.
