// src/ingestion/ingestion.module.ts
import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { PlatformSnifferService } from './platform-sniffer.service';
import { PlatformFastPathService } from './platform-fast-path.service';
import { SitemapDiscoveryService } from './sitemap-discovery.service';
import { SitemapCrawlerService, HTML_CRAWL_QUEUE } from './sitemap-crawler.service';
import { SitemapCrawlerProcessor } from './sitemap-crawler.processor';
import { JsonLdExtractor } from './extractors/json-ld.extractor';
import { ReadabilityExtractor } from './extractors/readability.extractor';

@Module({
  imports: [
    BullModule.registerQueue({
      name: HTML_CRAWL_QUEUE,
      defaultJobOptions: {
        attempts: 3,
        backoff: { type: 'exponential', delay: 2000 },
      },
    }),
    // Import your existing modules that export ProductService / KnowledgeService here:
    // ProductModule,
    // KnowledgeModule,
  ],
  providers: [
    PlatformSnifferService,
    PlatformFastPathService,
    SitemapDiscoveryService,
    SitemapCrawlerService,
    SitemapCrawlerProcessor,
    JsonLdExtractor,
    ReadabilityExtractor,
  ],
  exports: [SitemapCrawlerService],
})
export class IngestionModule {}
