// src/ingestion/types/ingestion.types.ts

export type PlatformType = 'shopify' | 'woocommerce' | 'custom';

export interface PlatformDetectionResult {
  platform: PlatformType;
  domain: string;
  confidence: 'high' | 'low';
  evidence: string[]; // human-readable reasons, useful for debugging/logging
}

export type DiscoveredUrlKind = 'product' | 'policy' | 'faq' | 'page' | 'unknown';

export interface DiscoveredUrl {
  url: string;
  kind: DiscoveredUrlKind;
  sourceHint?: 'sitemap' | 'platform-index' | 'nav-link';
}

export interface ExtractedProduct {
  sourceUrl: string;
  externalId?: string; // platform SKU / product id, if available
  title: string;
  description?: string;
  price?: number;
  currency?: string;
  images: string[];
  availability?: 'in_stock' | 'out_of_stock' | 'unknown';
  variants?: Array<{
    id?: string;
    title: string;
    price?: number;
    sku?: string;
    available?: boolean;
  }>;
  raw?: Record<string, unknown>; // original JSON-LD / platform payload for audit
}

export interface ExtractedKnowledgeDoc {
  sourceUrl: string;
  category: 'policy' | 'faq' | 'general';
  title: string;
  markdown: string;
}

export interface CrawlJobData {
  tenantId: string;
  domain: string; // e.g. "mystore.com" (no protocol)
}

export interface CrawlUrlJobData {
  tenantId: string;
  domain: string;
  platform: PlatformType;
  discovered: DiscoveredUrl;
}
