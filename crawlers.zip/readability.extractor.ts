// src/ingestion/extractors/readability.extractor.ts
import { Injectable, Logger } from '@nestjs/common';
import { JSDOM } from 'jsdom';
import { Readability } from '@mozilla/readability';
import TurndownService from 'turndown';
import { ExtractedKnowledgeDoc, DiscoveredUrlKind } from '../types/ingestion.types';

const MIN_CONTENT_LENGTH = 120; // below this, Readability likely grabbed nav/footer junk

/**
 * Strips chrome (nav, footer, ads) from a policy/FAQ/general page and
 * converts the remaining article body to clean Markdown for chunking
 * into the KnowledgeBase / vector index.
 */
@Injectable()
export class ReadabilityExtractor {
  private readonly logger = new Logger(ReadabilityExtractor.name);
  private readonly turndown = new TurndownService({
    headingStyle: 'atx',
    codeBlockStyle: 'fenced',
  });

  extract(
    html: string,
    sourceUrl: string,
    kind: Extract<DiscoveredUrlKind, 'policy' | 'faq' | 'page'>,
  ): ExtractedKnowledgeDoc | null {
    try {
      const dom = new JSDOM(html, { url: sourceUrl });
      const article = new Readability(dom.window.document).parse();

      if (!article?.content || article.textContent.trim().length < MIN_CONTENT_LENGTH) {
        this.logger.debug(`Readability yielded too little content for ${sourceUrl}, skipping`);
        return null;
      }

      const markdown = this.turndown.turndown(article.content).trim();

      return {
        sourceUrl,
        category: kind === 'page' ? 'general' : kind,
        title: article.title || this.titleFromUrl(sourceUrl),
        markdown,
      };
    } catch (err) {
      this.logger.warn(`Readability extraction failed for ${sourceUrl}: ${(err as Error).message}`);
      return null;
    }
  }

  private titleFromUrl(url: string): string {
    try {
      const path = new URL(url).pathname.replace(/\/+$/, '');
      const last = path.split('/').pop() || url;
      return last.replace(/[-_]/g, ' ').replace(/\.\w+$/, '');
    } catch {
      return url;
    }
  }
}
