// src/ingestion/sitemap-crawler.processor.ts
import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';
import { JsonLdExtractor } from './extractors/json-ld.extractor';
import { ReadabilityExtractor } from './extractors/readability.extractor';
import { CrawlUrlJobData } from './types/ingestion.types';
import { HTML_CRAWL_QUEUE } from './sitemap-crawler.service';

const USER_AGENT = 'ORA-Sync/1.0 (+https://ora.ai/bot; Storefront Intelligence)';
const FETCH_TIMEOUT_MS = 10_000;

/**
 * Per-URL worker for the generic crawl fallback (and the FAQ/page sweep
 * that runs alongside the Shopify/Woo fast paths). Concurrency is capped
 * both globally and per-tenant to stay polite to merchant origins.
 */
@Processor(HTML_CRAWL_QUEUE, {
  concurrency: 10, // global worker concurrency
  limiter: { max: 5, duration: 1000 }, // politeness: max 5 fetches/sec across all tenants
})
export class SitemapCrawlerProcessor extends WorkerHost {
  private readonly logger = new Logger(SitemapCrawlerProcessor.name);

  constructor(
    private readonly jsonLdExtractor: JsonLdExtractor,
    private readonly readabilityExtractor: ReadabilityExtractor,
    // private readonly productService: ProductService,
    // private readonly knowledgeService: KnowledgeService,
  ) {
    super();
  }

  async process(job: Job<CrawlUrlJobData>): Promise<void> {
    const { tenantId, discovered } = job.data;
    const html = await this.fetchHtml(discovered.url);

    if (!html) {
      this.logger.debug(`Skipping ${discovered.url}: fetch failed or non-HTML response`);
      return;
    }

    if (discovered.kind === 'product') {
      const product = this.jsonLdExtractor.extractProduct(html, discovered.url);
      if (!product) {
        this.logger.debug(`No JSON-LD/OG product data found at ${discovered.url}`);
        return;
      }
      // await this.productService.upsertOne(tenantId, product);
      this.logger.debug(`[product] tenant=${tenantId} title="${product.title}" url=${discovered.url}`);
      return;
    }

    if (discovered.kind === 'policy' || discovered.kind === 'faq' || discovered.kind === 'page') {
      const doc = this.readabilityExtractor.extract(html, discovered.url, discovered.kind);
      if (!doc) {
        this.logger.debug(`Readability found no substantial content at ${discovered.url}`);
        return;
      }
      // await this.knowledgeService.createKnowledgeBase(tenantId, {
      //   category: doc.category,
      //   title: doc.title,
      //   content: doc.markdown, // auto-chunked + embedded downstream
      //   sourceUrl: doc.sourceUrl,
      // });
      this.logger.debug(
        `[knowledge:${doc.category}] tenant=${tenantId} title="${doc.title}" url=${discovered.url}`,
      );
      return;
    }

    this.logger.debug(`Unclassified URL kind for ${discovered.url}, skipping`);
  }

  private async fetchHtml(url: string): Promise<string | null> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);

    try {
      const res = await fetch(url, {
        signal: controller.signal,
        headers: { 'User-Agent': USER_AGENT, Accept: 'text/html' },
      });

      if (!res.ok) return null;

      const contentType = res.headers.get('content-type') ?? '';
      if (!contentType.includes('text/html')) return null;

      return await res.text();
    } catch (err) {
      this.logger.debug(`fetchHtml failed for ${url}: ${(err as Error).message}`);
      return null;
    } finally {
      clearTimeout(timeout);
    }
  }
}
