// src/ingestion/sitemap-discovery.service.ts
import { Injectable, Logger } from '@nestjs/common';
import { XMLParser } from 'fast-xml-parser';
import { DiscoveredUrl, DiscoveredUrlKind } from './types/ingestion.types';

const USER_AGENT = 'ORA-Sync/1.0 (+https://ora.ai/bot; Storefront Intelligence)';
const MAX_URLS_PER_DOMAIN = 5000; // hard safety cap
const MAX_SITEMAP_DEPTH = 2; // sitemap index -> child sitemaps only, no deeper recursion

const POLICY_PATTERNS = [/\/policies?\//i, /refund/i, /shipping-policy/i, /terms-of-service/i, /privacy-policy/i];
const FAQ_PATTERNS = [/\/faq/i, /frequently-asked/i];
const PRODUCT_PATTERNS = [/\/products?\//i, /\/product\//i, /\/shop\//i, /\/item\//i];

@Injectable()
export class SitemapDiscoveryService {
  private readonly logger = new Logger(SitemapDiscoveryService.name);
  private readonly xmlParser = new XMLParser({ ignoreAttributes: false });

  async discover(domain: string): Promise<DiscoveredUrl[]> {
    const candidateSitemaps = [
      `https://${domain}/sitemap.xml`,
      `https://${domain}/sitemap_index.xml`,
    ];

    const seen = new Set<string>();
    const results: DiscoveredUrl[] = [];

    for (const sitemapUrl of candidateSitemaps) {
      const urls = await this.crawlSitemap(sitemapUrl, 0);
      for (const url of urls) {
        if (seen.has(url)) continue;
        seen.add(url);
        results.push({ url, kind: this.classify(url), sourceHint: 'sitemap' });
        if (results.length >= MAX_URLS_PER_DOMAIN) break;
      }
      if (results.length > 0) break; // first sitemap that resolves wins
    }

    if (results.length === 0) {
      this.logger.warn(`No sitemap discovered for ${domain}; caller should fall back to homepage nav crawl`);
    }

    return results;
  }

  private async crawlSitemap(url: string, depth: number): Promise<string[]> {
    if (depth > MAX_SITEMAP_DEPTH) return [];

    try {
      const res = await fetch(url, { headers: { 'User-Agent': USER_AGENT } });
      if (!res.ok) return [];

      const xml = await res.text();
      const parsed = this.xmlParser.parse(xml);

      // Sitemap index: <sitemapindex><sitemap><loc>...
      if (parsed.sitemapindex?.sitemap) {
        const children = this.toArray(parsed.sitemapindex.sitemap);
        const childUrls: string[] = [];
        for (const child of children) {
          if (child.loc) {
            const nested = await this.crawlSitemap(child.loc, depth + 1);
            childUrls.push(...nested);
          }
        }
        return childUrls;
      }

      // Regular urlset: <urlset><url><loc>...
      if (parsed.urlset?.url) {
        const entries = this.toArray(parsed.urlset.url);
        return entries.map((e: { loc: string }) => e.loc).filter(Boolean);
      }

      return [];
    } catch (err) {
      this.logger.debug(`Sitemap fetch failed for ${url}: ${(err as Error).message}`);
      return [];
    }
  }

  private toArray<T>(value: T | T[]): T[] {
    return Array.isArray(value) ? value : [value];
  }

  private classify(url: string): DiscoveredUrlKind {
    if (POLICY_PATTERNS.some((p) => p.test(url))) return 'policy';
    if (FAQ_PATTERNS.some((p) => p.test(url))) return 'faq';
    if (PRODUCT_PATTERNS.some((p) => p.test(url))) return 'product';
    return 'page';
  }
}
