// src/ingestion/platform-fast-path.service.ts
import { Injectable, Logger } from '@nestjs/common';
import { ExtractedKnowledgeDoc, ExtractedProduct } from './types/ingestion.types';

const USER_AGENT = 'ORA-Sync/1.0 (+https://ora.ai/bot; Storefront Intelligence)';
const PAGE_SIZE = 250; // Shopify's max per_page for /products.json

/**
 * Direct calls to platform-native public JSON APIs. No HTML parsing needed.
 * This is the "no scraping" path — Shopify and WooCommerce both intentionally
 * expose these endpoints unauthenticated for storefront use.
 */
@Injectable()
export class PlatformFastPathService {
  private readonly logger = new Logger(PlatformFastPathService.name);

  async fetchShopifyProducts(domain: string): Promise<ExtractedProduct[]> {
    const all: ExtractedProduct[] = [];
    let page = 1;

    while (page <= 40) {
      // 40 * 250 = 10k products hard cap, generous for a merchant catalog
      const res = await this.get(`https://${domain}/products.json?limit=${PAGE_SIZE}&page=${page}`);
      if (!res) break;

      const body = await res.json().catch(() => null);
      const products: any[] = body?.products ?? [];
      if (products.length === 0) break;

      for (const p of products) {
        all.push(this.mapShopifyProduct(p, domain));
      }

      if (products.length < PAGE_SIZE) break; // last page
      page += 1;
    }

    this.logger.log(`Fetched ${all.length} Shopify products for ${domain}`);
    return all;
  }

  async fetchShopifyPolicies(domain: string): Promise<ExtractedKnowledgeDoc[]> {
    const res = await this.get(`https://${domain}/policies.json`);
    if (!res) return [];

    const body = await res.json().catch(() => null);
    const policies: any[] = body?.policies ?? [];

    return policies
      .filter((p) => p.body && p.title)
      .map((p) => ({
        sourceUrl: p.url ?? `https://${domain}/policies`,
        category: 'policy' as const,
        title: p.title,
        // policies.json returns raw HTML in `body`; caller should still run it
        // through the Readability/Turndown pipeline for consistent Markdown.
        markdown: p.body,
      }));
  }

  async fetchWooCommerceProducts(domain: string): Promise<ExtractedProduct[]> {
    const all: ExtractedProduct[] = [];
    let page = 1;

    while (page <= 40) {
      const res = await this.get(
        `https://${domain}/wp-json/wc/store/v1/products?per_page=${PAGE_SIZE}&page=${page}`,
      );
      if (!res) break;

      const products: any[] = await res.json().catch(() => []);
      if (!Array.isArray(products) || products.length === 0) break;

      for (const p of products) {
        all.push(this.mapWooProduct(p, domain));
      }

      if (products.length < PAGE_SIZE) break;
      page += 1;
    }

    this.logger.log(`Fetched ${all.length} WooCommerce products for ${domain}`);
    return all;
  }

  async fetchWooCommercePages(domain: string): Promise<ExtractedKnowledgeDoc[]> {
    // WooCommerce sites don't have a policies.json equivalent; the standard
    // WP Pages API is the closest public source, filtered by slug on the caller side.
    const res = await this.get(`https://${domain}/wp-json/wp/v2/pages?per_page=100`);
    if (!res) return [];

    const pages: any[] = await res.json().catch(() => []);
    if (!Array.isArray(pages)) return [];

    return pages
      .filter((p) => p.content?.rendered)
      .map((p) => ({
        sourceUrl: p.link ?? `https://${domain}`,
        category: this.classifyWpPageSlug(p.slug),
        title: p.title?.rendered ?? p.slug,
        markdown: p.content.rendered, // raw HTML, run through Readability/Turndown downstream
      }));
  }

  private classifyWpPageSlug(slug: string): 'policy' | 'faq' | 'general' {
    if (/refund|shipping|privacy|terms/i.test(slug)) return 'policy';
    if (/faq/i.test(slug)) return 'faq';
    return 'general';
  }

  private mapShopifyProduct(p: any, domain: string): ExtractedProduct {
    const firstVariant = p.variants?.[0];
    return {
      sourceUrl: `https://${domain}/products/${p.handle}`,
      externalId: String(p.id),
      title: p.title,
      description: this.stripHtml(p.body_html),
      price: firstVariant?.price ? Number(firstVariant.price) : undefined,
      currency: undefined, // not included in /products.json; resolve via shop-level config if needed
      images: (p.images ?? []).map((img: any) => img.src).filter(Boolean),
      availability: firstVariant?.available ? 'in_stock' : 'out_of_stock',
      variants: (p.variants ?? []).map((v: any) => ({
        id: String(v.id),
        title: v.title,
        price: v.price ? Number(v.price) : undefined,
        sku: v.sku,
        available: v.available,
      })),
      raw: p,
    };
  }

  private mapWooProduct(p: any, domain: string): ExtractedProduct {
    return {
      sourceUrl: p.permalink ?? `https://${domain}/?p=${p.id}`,
      externalId: String(p.id),
      title: p.name,
      description: this.stripHtml(p.description ?? p.short_description),
      price: p.prices?.price ? Number(p.prices.price) / 100 : undefined, // Woo Store API returns minor units
      currency: p.prices?.currency_code,
      images: (p.images ?? []).map((img: any) => img.src).filter(Boolean),
      availability: p.is_in_stock ? 'in_stock' : 'out_of_stock',
      variants: (p.variations ?? []).map((v: any) => ({ id: String(v.id) })),
      raw: p,
    };
  }

  private stripHtml(html?: string): string | undefined {
    if (!html) return undefined;
    return html.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
  }

  private async get(url: string): Promise<Response | null> {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 8000);
      const res = await fetch(url, {
        signal: controller.signal,
        headers: { 'User-Agent': USER_AGENT, Accept: 'application/json' },
      }).finally(() => clearTimeout(timeout));

      if (!res.ok) {
        this.logger.debug(`Fast-path GET ${url} returned ${res.status}`);
        return null;
      }
      return res;
    } catch (err) {
      this.logger.debug(`Fast-path GET ${url} failed: ${(err as Error).message}`);
      return null;
    }
  }
}
