// src/ingestion/extractors/json-ld.extractor.ts
import { Injectable, Logger } from '@nestjs/common';
import * as cheerio from 'cheerio';
import { ExtractedProduct } from '../types/ingestion.types';

/**
 * Extracts Schema.org Product JSON-LD (and OpenGraph fallback) from a page's HTML.
 * This is the primary path for "custom" storefronts (Next.js, Magento, BigCommerce, etc.)
 * where there's no platform-native JSON API to hit directly.
 */
@Injectable()
export class JsonLdExtractor {
  private readonly logger = new Logger(JsonLdExtractor.name);

  extractProduct(html: string, sourceUrl: string): ExtractedProduct | null {
    const $ = cheerio.load(html);

    const fromJsonLd = this.extractFromJsonLd($, sourceUrl);
    if (fromJsonLd) return fromJsonLd;

    return this.extractFromOpenGraph($, sourceUrl);
  }

  private extractFromJsonLd($: cheerio.CheerioAPI, sourceUrl: string): ExtractedProduct | null {
    const scripts = $('script[type="application/ld+json"]');

    for (const el of scripts.toArray()) {
      const raw = $(el).contents().text();
      if (!raw) continue;

      let parsed: unknown;
      try {
        parsed = JSON.parse(raw);
      } catch {
        continue; // malformed JSON-LD is common; skip and try the next block
      }

      const candidates = Array.isArray(parsed) ? parsed : [parsed];
      // Some sites wrap schemas in @graph
      const flattened = candidates.flatMap((c: any) =>
        c && Array.isArray(c['@graph']) ? c['@graph'] : [c],
      );

      const productNode = flattened.find((node: any) => this.isProductType(node?.['@type']));
      if (productNode) {
        return this.mapJsonLdProduct(productNode, sourceUrl);
      }
    }

    return null;
  }

  private isProductType(type: unknown): boolean {
    if (!type) return false;
    const types = Array.isArray(type) ? type : [type];
    return types.some((t) => typeof t === 'string' && t.toLowerCase() === 'product');
  }

  private mapJsonLdProduct(node: any, sourceUrl: string): ExtractedProduct {
    const offer = Array.isArray(node.offers) ? node.offers[0] : node.offers;

    const images: string[] = Array.isArray(node.image)
      ? node.image
      : node.image
        ? [node.image]
        : [];

    return {
      sourceUrl,
      externalId: node.sku ?? node.productID ?? undefined,
      title: node.name ?? 'Untitled product',
      description: node.description ?? undefined,
      price: offer?.price ? Number(offer.price) : undefined,
      currency: offer?.priceCurrency ?? undefined,
      images,
      availability: this.mapAvailability(offer?.availability),
      raw: node,
    };
  }

  private mapAvailability(availability: unknown): ExtractedProduct['availability'] {
    if (typeof availability !== 'string') return 'unknown';
    if (/instock/i.test(availability)) return 'in_stock';
    if (/outofstock/i.test(availability)) return 'out_of_stock';
    return 'unknown';
  }

  private extractFromOpenGraph($: cheerio.CheerioAPI, sourceUrl: string): ExtractedProduct | null {
    const title = $('meta[property="og:title"]').attr('content');
    if (!title) return null; // not enough signal to call this a product page

    const price = $('meta[property="og:price:amount"]').attr('content');
    const currency = $('meta[property="og:price:currency"]').attr('content');
    const image = $('meta[property="og:image"]').attr('content');

    return {
      sourceUrl,
      title,
      description: $('meta[property="og:description"]').attr('content'),
      price: price ? Number(price) : undefined,
      currency,
      images: image ? [image] : [],
      availability: 'unknown',
    };
  }
}
